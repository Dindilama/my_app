import mysql.connector

try:
    conexion = mysql.connector.connect(
        host='localhost',
        user='root',
        passwd='',
        database='base_prueba'
    )
except Exception as err:
    print('ERROR CONECTANDO A LA BASE:', err)
else:
    print('CONECTADO A MYSQL')

    cur01 = conexion.cursor()
    insertar = "INSERT INTO usuarios VALUES (1002, 'Laura', '123456')"

    try:
        cur01.execute(insertar)
        conexion.commit()
        print('Inserción exitosa')
    except Exception as err:
        print('ERROR AL INSERTAR DATOS:', err)

    conexion.close()